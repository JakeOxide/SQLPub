CREATE TABLE NameCaps (
	fname varchar(255),
	lname varchar(255)
	);

INSERT INTO NameCaps VALUES ('abdullah','aliyas');
INSERT INTO NameCaps VALUES ('abdurehman','adem');
INSERT INTO NameCaps VALUES ('abel','tsegaye');
