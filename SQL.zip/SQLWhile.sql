CREATE TABLE Employee (
	id int,
	name varchar(50),
	salary money
	);


INSERT INTO Employee VALUES (1, 'AAA', 2);
INSERT INTO Employee VALUES (2, 'BBB', 8);
INSERT INTO Employee VALUES (3, 'CCC', 6);
INSERT INTO Employee VALUES (4, 'DDD', 10);
INSERT INTO Employee VALUES (5, 'EEE', 3);
INSERT INTO Employee VALUES (6, 'FFF', 19205);
INSERT INTO Employee VALUES (7, 'GGG', 1520);
INSERT INTO Employee VALUES (8, 'HHH', 7000);


/* --------------- Given Code --------------- */

WHILE(SELECT SUM(salary) FROM Employee) < 39
BEGIN
		UPDATE Employee
		SET salary += 1
		WHERE (SELECT MIN(salary) FROM Employee) <= 12

	IF (SELECT MIN(salary) FROM Employee) > 39
		BREAK
	ELSE
		CONTINUE
END

/* --------------- Given Code --------------- */



/* --------------- Updated Code --------------- */

WHILE(SELECT SUM(salary) FROM Employee) < 150000
BEGIN
	IF (SELECT MIN(salary) FROM Employee) < 7000
		UPDATE Employee
		SET salary += 100 

	ELSE IF (SELECT MIN(salary) FROM Employee) >= 7000
		BREAK
END

/* --------------- Updated Code --------------- */

SELECT * FROM Employee;

DECLARE @totSalary int = (SELECT SUM(salary) FROM Employee);

PRINT @totSalary;


DROP TABLE Employee;