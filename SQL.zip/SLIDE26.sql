/* ANSWER FOR EXERCISE ON SLIDE 26 */

CREATE TABLE Student (
	ID int IDENTITY,
	FullName varchar(255),
	Batch varchar(25)
	);

INSERT INTO Student VALUES ('Abdullah Lliyas','DRB2001');
INSERT INTO Student VALUES ('Abdurehman Adem','DRB2001');
INSERT INTO Student VALUES ('Abel Tsegaye','DRB2001');
INSERT INTO Student VALUES ('Abiselom Mesfin','DRB2001');
INSERT INTO Student VALUES ('Abreham Gebremedhin','DRB2001');
INSERT INTO Student VALUES ('Abrham Alem','DRB2001');

SELECT * FROM Student

CREATE TABLE StudentClean (
	ID int IDENTITY,
	FName varchar(100),
	LName varchar(100),
	Batch varchar(25)
	);

/* SCRIPT */
DECLARE @X int = -1;
DECLARE @COUNT int = (SELECT COUNT(*) FROM Student);

WHILE (@X <= @COUNT)
BEGIN
	DECLARE @CheckData varchar(255) = (SELECT TRIM(FullName) FROM Student);
	DECLARE @SpaceIndex int = CHARINDEX(@CheckData, ' ', 1);
	DECLARE @FNAME varchar(100) = (SELECT LEFT(@CheckData, (@SpaceIndex - 1)));
	DECLARE @LNAME varchar(100) = (SELECT LEFT(@CheckData, (@SpaceIndex + 1)));

	INSERT INTO StudentClean VALUES (@FNAME, @LNAME, 'DRB2001');
END

SELECT * FROM StudentClean

/*

DECLARE @DataTable TABLE 
(
	Fname varchar(100),
	Lname varchar(100)
)
INSERT @DataTable (Fname) SELECT LEFT(@CheckData, (@SpaceIndex - 1));
INSERT @DataTable (Lname) SELECT LEFT(@CheckData, (@SpaceIndex + 1));


DECLARE @FNAME varchar(100) = (SELECT LEFT(@CheckData, (@SpaceIndex - 1)));
DECLARE @LNAME varchar(100) = (SELECT LEFT(@CheckData, (@SpaceIndex + 1)));
*/