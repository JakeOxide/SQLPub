/* ANSWERS FOR EXERCISE ON SLIDE 51 */

/* ----- 1 ----- */

DECLARE @CurDate DATE;

SET @CurDate = GETDATE();

PRINT @CurDate;

/* ----- 1 ----- */

/* ----- 2 ----- */

CREATE TABLE EmployeeTable (
	FName varchar(10),
	LName varchar(10)
	);

INSERT INTO EmployeeTable VALUES ('aaaaa', 'bbbbb');
INSERT INTO EmployeeTable VALUES ('ccccc', 'ddddd');
INSERT INTO EmployeeTable VALUES ('eeeee', 'fffff');

UPDATE EmployeeTable 
SET FName = UPPER(FName), LName = UPPER(LName)

/*

OUTPUT

FName	LName
AAAAA	BBBBB
CCCCC	DDDDD
EEEEE	FFFFF

*/

/* ----- 2 ----- */

/* ----- 3 ----- */

CREATE TABLE Employee2 (
	ID int,
	FName varchar(10),
	LName varchar(10),
	Age int,
	Department varchar(50)
	);

INSERT INTO Employee2 VALUES (1, 'FEMP1', 'LEMP1', 20, 'Computer Science');
INSERT INTO Employee2 VALUES (2, 'FEMP2', 'LEMP2', 21, 'Software Engineering');
INSERT INTO Employee2 VALUES (3, 'FEMP3', 'LEMP3', 22, 'Computer Science');

DECLARE @DataTable TABLE
(
	fname varchar(10),
	lname varchar(10),
	dep varchar(50)
)

INSERT INTO @DataTable (fname, lname, dep)
SELECT FName, LName, Department FROM Employee2;

SELECT fname, lname, dep FROM @DataTable;

/*

OUTPUT

fname	lname	dep
FEMP1	LEMP1	Computer Science
FEMP2	LEMP2	Software Engineering
FEMP3	LEMP3	Computer Science

*/

/* ----- 3 ----- */